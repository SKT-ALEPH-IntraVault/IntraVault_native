<?php
return [
    'default'=>'local',
    'disks'=>[
        'local'=>[
            'driver'=>'local',
            'root'=>storage_path('app/private'),
            'serve'=>false,
            'visibility'=>'private',
            'throw'=>true,
            'report'=>true,
        ],
    ],
    'links'=>[],
];
