<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AuditLog extends Model {
    public $timestamps=false;
    protected $guarded=['id'];
    protected function casts(): array { return ['context'=>'array','created_at'=>'datetime']; }
    public function user() { return $this->belongsTo(User::class); }
}
