<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Transport adaptation only: existing routes, policies and Blade remain authoritative. */
class WorkspaceResponse
{
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);
        if ($request->header('X-IntraVault') === 'workspace' && !$request->isMethod('GET')
            && in_array($response->getStatusCode(), [302, 303], true)) {
            return response('', 204)->header('X-IntraVault-Location', $response->headers->get('Location'));
        }
        return $response;
    }
}
