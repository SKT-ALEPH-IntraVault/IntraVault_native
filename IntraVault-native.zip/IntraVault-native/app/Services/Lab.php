<?php
namespace App\Services;
use App\Models\LabFlag;
class Lab {
    public function enabled(string $id): bool {
        if (!config('lab.enabled') || !array_key_exists($id,config('lab.vulnerabilities'))) return false;
        // Read each time: no stale global/session cache after OFF or between workers.
        return (bool) LabFlag::whereKey($id)->value('enabled');
    }
}
