# IntraVault — VMware 네이티브 실행본

Docker 없이 PHP·Composer·MariaDB로 실행하는 별도 복사본입니다. Laravel·Blade·Bootstrap UI와 업무/훈련 기능을 유지했습니다. 이 README가 네이티브 실행 기준입니다. docs와 RULE.md의 Docker 관련 내용은 과거 설계·검증 기록입니다.

## 필요한 환경

- VMware Linux 게스트와 Bash
- PHP 8.4.1 이상(8.4 계열 권장), Composer 2
- PHP 확장: pdo_mysql, mbstring, xml/dom, curl, zip, intl, gd, fileinfo 및 PHP 기본 확장
- MariaDB: 원본은 11.4 사용. 이 전달본의 VM 버전별 실행은 미검증입니다.

composer.json은 PHP ^8.3이지만 composer.lock의 Symfony 의존성은 8.4.1 이상을 요구합니다. PHP 8.3으로 잠금 파일 그대로 설치할 수 없습니다. VM 운영체제에 맞게 위 프로그램을 설치한 뒤 php -v, composer --version, mariadb --version으로 확인하세요.

Bootstrap 파일은 public/assets에 포함되어 실행에 Node.js나 npm 빌드가 필요하지 않습니다.

## 최초 준비

압축을 VM 사용자 홈 디렉터리에 풀고 IntraVault-native 폴더에서 실행합니다.

```bash
cp .env.example .env
nano .env
nano native/database.sql
```

두 파일의 replace-with-random-password와 replace-with-reader-password를 각각 서로 다른 비밀번호로 교체합니다. 두 파일에 같은 값을 사용하세요. SQL 인용 문제를 피하려면 영문·숫자로 된 충분히 긴 임의 값을 사용하세요. DB 이름과 계정은 예제 값을 유지합니다.

VM 내부의 MariaDB에 로컬 소켓으로 연결해 새 DB와 계정을 생성합니다.

```bash
sudo systemctl enable --now mariadb
sudo mariadb --protocol=socket < native/database.sql
bash native/setup.sh
php artisan intravault:create-admin
```

SQL은 최초 한 번만 실행합니다. DB나 계정이 이미 있다는 오류가 나오면 중단하고 상태를 확인하세요. 삭제·초기화 명령은 포함하지 않았습니다. setup.sh는 일반 사용자로 실행합니다. 관리자 이름, 이메일, 사번, 부서, 부서 코드, 12자 이상 비밀번호를 입력합니다. 기본 로그인 계정과 데모 데이터는 자동 생성하지 않습니다.

## 실행

```bash
bash native/start.sh
```

VM 브라우저에서 http://localhost:18080 에 접속합니다. 종료는 Ctrl+C입니다. PHP 개발 서버를 사용하는 로컬 실습용 실행 방식입니다.

Windows에서 접속하려면 VM의 SSH 서비스가 준비된 상태에서 Windows 터미널에 다음을 실행하고 유지합니다.

```text
ssh -N -L 18080:127.0.0.1:18080 VM사용자@VM_IP
```

Windows 브라우저도 http://localhost:18080 을 엽니다.

## 데이터와 변경 사항

- 업무 DB: intravault_vmware
- 훈련 DB: intravault_vmware_lab
- 훈련 읽기 계정: intravault_vmware_reader (SELECT만 허용)
- 업로드: 이 복사본의 storage/app/private
- PHP 업로드 한도 40M, POST 42M, 메모리 256M, 실행 시간 120초

원본 ZIP과 기존 배포본은 변경하지 않았습니다. 운영 .env, 운영 DB와 업로드는 가져오지 않았습니다.

사용자 요청에 따라 전달본에서 Dockerfile, Compose 파일, docker·deploy 폴더, 과거 배포 ZIP을 제외했습니다. scripts 중 자산 빌드 스크립트만 유지하고 기존 배포·컨테이너용 도구와 검증 보조 스크립트는 제외했습니다. 기존 README는 docs/README-original.md에 보존했습니다. tests의 기존 테스트 코드는 유지했으며 별도 테스트 DB 구성 전에는 실행하지 마세요.

ARC-01~06의 애플리케이션 구성을 유지하고 로컬 실행 방식만 변경했습니다. 훈련 읽기 계정은 LAB_DB_USERNAME으로 지정하도록 변경했습니다. 업무 로직과 화면은 변경하지 않았습니다.

## 검증 범위

소스 대조, Bash 문법과 패키지 구성을 검사했습니다. 작업 환경에 PHP·MariaDB가 없어 의존성 설치, 마이그레이션, HTTP 응답, 기능 테스트는 실행하지 않았습니다. 최초 설치 시 setup.sh에서 Composer 요구사항·마이그레이션·앱 상태를 확인합니다.