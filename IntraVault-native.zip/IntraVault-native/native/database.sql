-- VMware guest only. Replace both passwords here and in .env before running.
-- Run once. Existing databases/users cause an error; do not use --force.
CREATE DATABASE intravault_vmware CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE intravault_vmware_lab CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'intravault_vmware'@'127.0.0.1' IDENTIFIED BY 'replace-with-random-password';
CREATE USER 'intravault_vmware_reader'@'127.0.0.1' IDENTIFIED BY 'replace-with-reader-password';
GRANT ALL PRIVILEGES ON intravault_vmware.* TO 'intravault_vmware'@'127.0.0.1';
GRANT ALL PRIVILEGES ON intravault_vmware_lab.* TO 'intravault_vmware'@'127.0.0.1';
GRANT SELECT ON intravault_vmware_lab.* TO 'intravault_vmware_reader'@'127.0.0.1';
