#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -f vendor/autoload.php ]] || { echo 'Run bash native/setup.sh first.' >&2; exit 1; }
export PHP_INI_SCAN_DIR="${PHP_INI_SCAN_DIR:-}:$PWD/native"
php artisan config:clear
php native/check-local.php
exec php artisan serve --host=127.0.0.1 --port=18080
