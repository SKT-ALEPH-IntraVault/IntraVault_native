#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$EUID" -eq 0 ]]; then echo 'Run as your normal VM user, without sudo.' >&2; exit 1; fi
php -r 'if (PHP_VERSION_ID < 80401) {fwrite(STDERR,"PHP 8.4.1+ required\n"); exit(1);}'
[[ -f .env ]] || { echo 'Copy .env.example to .env and configure the database first.' >&2; exit 1; }
chmod 600 .env
mkdir -p storage/app/private storage/framework/{sessions,views,cache/data} storage/logs bootstrap/cache
export PHP_INI_SCAN_DIR="${PHP_INI_SCAN_DIR:-}:$PWD/native"
composer install --no-interaction --prefer-dist --optimize-autoloader
composer check-platform-reqs
php artisan config:clear
php native/check-local.php
if ! grep -Eq '^APP_KEY=base64:.+' .env; then php artisan key:generate; fi
php artisan migrate --seed
php artisan intravault:check
echo 'Setup complete. Create your administrator: php artisan intravault:create-admin'
