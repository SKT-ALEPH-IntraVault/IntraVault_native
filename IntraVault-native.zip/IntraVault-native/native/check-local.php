<?php
require dirname(__DIR__).'/vendor/autoload.php';
$app = require dirname(__DIR__).'/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$db = config('database.connections.mariadb');
if (!app()->environment('local') || config('database.default') !== 'mariadb'
    || $db['host'] !== '127.0.0.1' || $db['database'] !== 'intravault_vmware'
    || $db['username'] !== 'intravault_vmware' || !empty($db['url']) || !empty($db['unix_socket'])
    || config('database.connections.lab_read.username') !== 'intravault_vmware_reader') {
    fwrite(STDERR, "Use the VMware .env with local MariaDB and VMware database/users.\n");
    exit(1);
}
foreach (['mariadb','lab_read'] as $name) {
    $password = config("database.connections.$name.password");
    if (!$password || str_starts_with($password, 'replace-with-')) {
        fwrite(STDERR, "Replace passwords in .env and native/database.sql first.\n");
        exit(1);
    }
}
echo "Local VMware configuration checked.\n";
