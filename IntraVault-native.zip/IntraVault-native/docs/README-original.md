# IntraVault

2026-09-11: [보안 ON/OFF 설계](docs/14-security-controls.md)와 [16개 제어 실습](docs/15-security-controls-practice.md)을 반영했다. Security Lab에서 전체 보안 ON·OFF 또는 개별 항목을 선택한다. **ON은 방어 적용, OFF는 해제**다. Vultr 배포와 실제 HTTPS 검증 완료. [배포 기록](docs/16-release-20260911.md)을 참조한다.
Laravel 13 + Blade + MariaDB + Bootstrap 5 기반 사내 문서관리와 통제된 보안 실습 플랫폼.

## Vultr에서 열기
- 웹: https://intravault.duckdns.org
- 관리자: https://intravault.duckdns.org/admin
- 서버 전용 접속 정보: [.setup/vultr-access.md](.setup/vultr-access.md)
- [현재 운영 및 WTR Pro NAS 이전](docs/10-vultr-nas.md)

## 이 PC에서 열기
- 프로젝트: D:\workspace\IntraVault
- 웹: http://localhost:18080
- 검증용 계정: [.setup/preview-access.md](.setup/preview-access.md)
- 시작: docker compose up -d
- 상태: docker compose ps
- 종료: docker compose stop

화면 데이터는 검증 Fixture이며 최종 회사·직원·문서 Seed가 아니다.
이전 V01~V10은 호환용이며 기본 OFF다. 새 Security Lab은 S01~S16 보안 제어를 표시하며 신규 설정은 모두 ON이다. 기존 V 상태의 전환 규칙은 보안 제어 설계를 따른다.

## 작업 기준
[RULE.md](RULE.md)가 사용자 지정 기능·제약 기준이다.
[AGENTS.md](AGENTS.md)는 작업 규칙 진입점이며 [구현 결정](docs/decisions.md)은 원문과 구현 선택을 구분한다.

## 문서 읽는 순서
[전체 문서 안내](docs/00-document-guide.md) → [설계 요약](docs/11-design-summary.md) → [NAS 이전 실행 절차](docs/10-vultr-nas.md)

## 실습용 더미데이터
서버에 4개 부서·13개 계정·24개 문서를 반영했다. [데이터와 비교 시나리오](docs/12-demo-data.md), [더미계정 표](docs/13-demo-accounts.md)를 참조한다. 계정표는 사용자 요청에 따라 private 저장소 보관용 비밀번호를 포함한다.

## 산출물
1. [요구사항 명세](docs/01-requirements.md)
2. [시스템 구조](docs/02-system-architecture.md)
3. [DB 구조](docs/03-database.md)
4. [테스트·더미데이터 구조](docs/04-test-data.md)
5. [실행·배포 README](docs/05-run-deploy.md)
6. [취약점 목록](docs/06-vulnerabilities.md)
7. [취약점 재현조건](docs/07-reproduction-conditions.md)
8. [정상/취약 비교](docs/08-normal-vulnerable-comparison.md)
9. [검증 시나리오와 실제 결과](docs/09-validation.md)

[요구사항 추적표](docs/traceability.md) · [반례/품질 검토](docs/review.md) · [원본 Notion](https://app.notion.com/p/3d70def9f626809abb60f42ef3733204)

## 검증
~~~powershell
docker compose exec app php artisan test --compact --log-junit docs/evidence/phpunit.xml
node scripts/browser-check.cjs
~~~

실행한 검증과 미검증 영역은 docs/09-validation.md에서 구분한다.
2026-09-10: Vultr·DuckDNS·HTTPS 배포 및 별도 프로젝트 백업 복원 검증 완료. 실제 NAS에서의 실행과 DNS 전환은 추후 수행한다.


2026-09-11 10:52 KST: 둥근 UI와 축소된 부서 카드 디자인 배포 완료. [디자인 원칙·배포 검증](docs/17-ui-principles.md).


## 부분 갱신 업무공간
2026-09-11 로컬 구현: 목록 부분 갱신·문서 패널·저장/공유/복구·탐색 이력. [요구사항 추적·검증·실행·복구](docs/19-incremental-workspace.md). 2026-09-11 공개 서버 배포 완료. [실제 웹 검증·백업·복구 기록](docs/20-workspace-release.md).


2026-09-11 후속 UI 개정: 관련 화면을 내부 탭으로 통합하고 컴포넌트 전환 효과를 적용했으며 내부 로딩 표시를 제거했다. 로컬 검증 및 공개 배포 완료. [통합 구성·검증](docs/21-grouped-workspace.md) · [실제 배포 기록](docs/22-grouped-workspace-release.md).
